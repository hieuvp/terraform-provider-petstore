self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c39b8329883cb3a6a3fdc8f104a7702c",
    "url": "./ui/index.html"
  },
  {
    "revision": "9d35a34ae2923739954d",
    "url": "./ui/static/js/2.dac4b64e.chunk.js"
  },
  {
    "revision": "879b16d687fe847b0ca9becae49bebfa",
    "url": "./ui/static/js/2.dac4b64e.chunk.js.LICENSE"
  },
  {
    "revision": "9889a457a1f83620b62a",
    "url": "./ui/static/js/main.87aba700.chunk.js"
  },
  {
    "revision": "bb2dbb964886b571636a",
    "url": "./ui/static/js/runtime-main.c7f2f0f5.js"
  }
]);